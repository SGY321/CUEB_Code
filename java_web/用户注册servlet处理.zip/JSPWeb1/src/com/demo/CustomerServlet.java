package com.demo;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/CustomerServlet")   
public class CustomerServlet extends HttpServlet {
   public void doPost(HttpServletRequest request,HttpServletResponse response) 
		   throws java.io.IOException,ServletException {
	
	request.setCharacterEncoding("UTF-8");             //防止中文乱码
    HttpSession session = request.getSession();
    synchronized(session) {
        session.setAttribute("customer",new Customer(request.getParameter("custName"),
        		request.getParameter("email"),request.getParameter("phone")));
    }
    RequestDispatcher rd = request.getRequestDispatcher("/displayCustomer.jsp");
    rd.forward(request,response); 
  }
} 

