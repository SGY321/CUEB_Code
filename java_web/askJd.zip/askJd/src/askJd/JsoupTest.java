package askJd;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * 解析京东界面, 爬取商品数据
 */
public class JsoupTest {
    static String url = "https://search.jd.com/Search?keyword=手机&enc=utf-8";

    public static void main(String[] args) throws IOException {
        // 设置cookie
        Map<String, String> cookies = new HashMap<String, String>();
        cookies.put("thor", "BFAECD1731B991B5CA6DED5E95CF7D2E27BD019B1AF4C0B8F648D0DCF9DA2479A09C66C9902C1D2096DA7039608F04A8206998C3720F6A5E0DA583EA3900C4ADB6D22524C042B38B44EF7B0F9F9F9DA283A77C9A61D8BC66C6113B7B22D7BC6024E7B28B635577222CA889E46E6172AC2676546DD1B92A2AEFD2713C8CA78518A880E9A99F7B449BBA801AC657B31E15C6D8839D0262EC5359FE74F8065998FD");
        // 解析网页, document就代表网页界面
        Document document = Jsoup.connect(url).cookies(cookies).get();

        // 通过class获取ul标签
        Elements ul = document.getElementsByClass("gl-warp clearfix");
        // 获取ul标签下的所有li标签
        Elements liList = ul.select("li");
        for (Element element : liList) {
            System.out.println("------------------");
            String pict = element.getElementsByTag("img").first().attr("data-lazy-img");
            String price = element.getElementsByClass("p-price").first().text();
            String pname = element.getElementsByClass("p-name").first().text();
            String shopName = element.getElementsByClass("p-shop").first().text();
            System.out.println(pict);
            System.out.println(price);
            System.out.println(pname);
            System.out.println(shopName);
        }
    }
}