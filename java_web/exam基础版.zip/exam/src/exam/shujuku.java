package exam;
import java.io.*;
import java.sql.*;
import java.util.*;

public class shujuku {
	public Connection getConn(){
		Connection conn = null;
		
		Properties pp = new Properties();
		InputStream in = getClass().getClassLoader().getResourceAsStream("db.Property");
		try {
			pp.load(in);
			String dbClass = pp.getProperty("dbClass");
			String dbUrl = pp.getProperty("dbUrl");
			String dbUser = pp.getProperty("dbUser");
			String dbPass = pp.getProperty("dbPass");
			
			try {
				Class.forName(dbClass);
				try {
					conn = DriverManager.getConnection(dbUrl,dbUser,dbPass);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;
	}
	
	public ResultSet getResult(String sql){
		ResultSet rs =null;
		
		Connection conn = getConn();
		try {
			Statement st = conn.createStatement();
			rs = st.executeQuery(sql);
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return rs;
		
	}
	
	public int changeContent(String sql){
		int resultV= 0 ;
		
		Connection conn = getConn();
		try {
			Statement st = conn.createStatement();
			resultV = st.executeUpdate(sql);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return resultV;
	}
}
