package com.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ShowTimeServlet")
public class ShowTimeServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		response.setHeader("Refresh", "1");  //设置刷新的时间间隔
		PrintWriter out = response.getWriter();
		LocalTime now = LocalTime.now();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("HH:mm:ss");//设置时间格式
		String t = now.format(format);
		Calendar calendar = Calendar.getInstance();
		int dayofweek =calendar.get(Calendar.DAY_OF_WEEK);
		String[] weekdays = {"","星期天","星期一","星期二","星期三","星期四","星期五","星期六"};
		
	    out.println("<html>");
		out.println("<head><title>当前时间</title></head>");
		out.println("<body>");
		out.println("<p>每秒刷新一次页面<p>");
		out.println("<p>现在的时间是:"+t+"<p>");
		out.println("<p>"+weekdays[dayofweek]+"<p>");
		out.println("</body>");
		out.println("</html>");





		
		
		
		
	}


}
