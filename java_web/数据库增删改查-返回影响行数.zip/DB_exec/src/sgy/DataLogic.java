package sgy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataLogic {
    
    public int getNumberOfRows(String command, Connection conn, String tableName, String condition, String fieldsStr, String valuesStr) {
        int rowsAffected = 0;
        String sql = "";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            if (command.equals("insert")) {
                // 构建插入语句
                sql = "INSERT INTO " + tableName + " (" + fieldsStr + ") VALUES (" + valuesStr + ")";
            } else if (command.equals("update")) {
                // 构建更新语句
                
               sql = "UPDATE " + tableName + " SET " + fieldsStr + " = " + valuesStr + " WHERE " + condition;
            } else if (command.equals("delete")) {
                // 构建删除语句
                sql = "DELETE FROM "+tableName+" WHERE " +condition;
            } else if (command.equals("select")) {
                // 构建查询语句
                sql = "SELECT COUNT(*) FROM " + tableName + " WHERE " + condition;

                // 执行查询语句
                ps = conn.prepareStatement(sql);
                rs = ps.executeQuery();

                // 获取查询结果
                if (rs.next()) {
                    rowsAffected = rs.getInt(1);
                }
            }

            // 执行增删改语句
            if (!command.equals("select")) {
                ps = conn.prepareStatement(sql);
                rowsAffected = ps.executeUpdate();
            }

        } catch (SQLException e) {
            // 处理异常
            e.printStackTrace();
      
        }

        return rowsAffected;
    }
}
